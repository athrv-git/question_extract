"""
RFI Excel Sheet Processor
A Streamlit application to convert Excel sheets to structured JSON via markdown
"""

import streamlit as st
import pandas as pd
import tempfile
import json
import os
from pathlib import Path

# Import custom modules
from excel_processor import ExcelProcessor
from markdown_converter import MarkdownConverter
from azure_extractor import AzureTableExtractor
from config import Config

# Page configuration
st.set_page_config(
    page_title="RFI Excel Processor",
    page_icon="📊",
    layout="wide"
)

def initialize_session_state():
    """Initialize session state variables"""
    if 'processed_data' not in st.session_state:
        st.session_state.processed_data = None
    if 'markdown_files' not in st.session_state:
        st.session_state.markdown_files = {}
    if 'extracted_tables' not in st.session_state:
        st.session_state.extracted_tables = {}

def main():
    """Main application function"""
    initialize_session_state()
    
    # Title and description
    st.title("🔧 RFI Excel Sheet Processor")
    st.markdown("""
    This application processes RFI Excel sheets by:
    1. Converting all sheets to markdown format
    2. Extracting structured tables using Azure OpenAI GPT-4
    3. Returning structured JSON with all columns and values
    """)
    
    # Sidebar for configuration
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        # Azure OpenAI settings
        st.subheader("Azure OpenAI Settings")
        api_key = st.text_input("API Key", type="password", key="azure_api_key")
        endpoint = st.text_input("Endpoint URL", placeholder="https://your-resource.openai.azure.com/")
        deployment_name = st.text_input("Deployment Name", placeholder="gpt-4o")
        
        # Save configuration
        if st.button("Save Configuration"):
            Config.set_azure_config(api_key, endpoint, deployment_name)
            st.success("Configuration saved!")
    
    # Main content area
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.header("📁 Upload Excel File")
        uploaded_file = st.file_uploader(
            "Choose an Excel file",
            type=['xlsx', 'xls', 'xlsm'],
            help="Upload your RFI Excel sheet for processing"
        )
        
        if uploaded_file is not None:
            st.success(f"File uploaded: {uploaded_file.name}")
            
            # Display file info
            file_details = {
                "Filename": uploaded_file.name,
                "File Size": f"{uploaded_file.size / 1024:.2f} KB",
                "File Type": uploaded_file.type
            }
            st.json(file_details)
    
    with col2:
        st.header("🔄 Processing Options")
        
        # Processing options
        include_empty_cells = st.checkbox("Include empty cells", value=False)
        preserve_formatting = st.checkbox("Preserve cell formatting info", value=True)
        merge_cells_handling = st.selectbox(
            "Merged cells handling",
            ["Expand to all cells", "Keep first cell only", "Mark as merged"]
        )
        
        # Process button
        if st.button("🚀 Process Excel File", type="primary", disabled=not uploaded_file):
            if not Config.is_configured():
                st.error("Please configure Azure OpenAI settings in the sidebar first!")
            else:
                process_excel_file(
                    uploaded_file, 
                    include_empty_cells, 
                    preserve_formatting,
                    merge_cells_handling
                )
    
    # Results section
    if st.session_state.processed_data:
        display_results()

def process_excel_file(uploaded_file, include_empty_cells, preserve_formatting, merge_cells_handling):
    """Process the uploaded Excel file"""
    try:
        with st.spinner("Processing Excel file..."):
            # Save uploaded file temporarily
            with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_file:
                tmp_file.write(uploaded_file.getvalue())
                tmp_path = tmp_file.name
            
            # Initialize processors
            excel_processor = ExcelProcessor(
                include_empty_cells=include_empty_cells,
                preserve_formatting=preserve_formatting,
                merge_cells_handling=merge_cells_handling
            )
            markdown_converter = MarkdownConverter()
            azure_extractor = AzureTableExtractor()
            
            # Step 1: Read Excel file
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            status_text.text("Reading Excel file...")
            sheets_data = excel_processor.read_excel(tmp_path)
            progress_bar.progress(25)
            
            # Step 2: Convert to Markdown
            status_text.text("Converting to Markdown...")
            markdown_files = {}
            for sheet_name, sheet_data in sheets_data.items():
                markdown_content = markdown_converter.convert_to_markdown(sheet_data, sheet_name)
                markdown_files[sheet_name] = markdown_content
            st.session_state.markdown_files = markdown_files
            progress_bar.progress(50)
            
            # Step 3: Extract tables using Azure OpenAI
            status_text.text("Extracting structured tables with Azure OpenAI...")
            extracted_tables = {}
            for sheet_name, markdown_content in markdown_files.items():
                tables_json = azure_extractor.extract_tables(markdown_content, sheet_name)
                extracted_tables[sheet_name] = tables_json
            st.session_state.extracted_tables = extracted_tables
            progress_bar.progress(100)
            
            # Store processed data
            st.session_state.processed_data = {
                'filename': uploaded_file.name,
                'sheets': list(sheets_data.keys()),
                'timestamp': pd.Timestamp.now().isoformat()
            }
            
            # Clean up temporary file
            os.unlink(tmp_path)
            
            status_text.text("✅ Processing complete!")
            st.success("Excel file processed successfully!")
            
    except Exception as e:
        st.error(f"Error processing file: {str(e)}")
        st.exception(e)

def display_results():
    """Display processing results"""
    st.header("📊 Results")
    
    # Create tabs for different views
    tab1, tab2, tab3, tab4 = st.tabs(["Summary", "Markdown Files", "Extracted Tables", "JSON Export"])
    
    with tab1:
        st.subheader("Processing Summary")
        st.json(st.session_state.processed_data)
        
        # Display sheet statistics
        st.subheader("Sheet Statistics")
        for sheet_name in st.session_state.processed_data['sheets']:
            with st.expander(f"📄 {sheet_name}"):
                if sheet_name in st.session_state.extracted_tables:
                    tables = st.session_state.extracted_tables[sheet_name]
                    st.write(f"Number of tables extracted: {len(tables.get('tables', []))}")
                    for i, table in enumerate(tables.get('tables', [])):
                        st.write(f"Table {i+1}: {len(table.get('rows', []))} rows × {len(table.get('columns', []))} columns")
    
    with tab2:
        st.subheader("Markdown Files")
        for sheet_name, markdown_content in st.session_state.markdown_files.items():
            with st.expander(f"📝 {sheet_name}.md"):
                st.code(markdown_content, language='markdown')
                
                # Download button for markdown
                st.download_button(
                    label=f"Download {sheet_name}.md",
                    data=markdown_content,
                    file_name=f"{sheet_name}.md",
                    mime="text/markdown"
                )
    
    with tab3:
        st.subheader("Extracted Tables (Structured JSON)")
        for sheet_name, tables_data in st.session_state.extracted_tables.items():
            with st.expander(f"🗂️ {sheet_name} Tables"):
                # Display JSON
                st.json(tables_data)
                
                # Display as DataFrame if possible
                if 'tables' in tables_data:
                    for i, table in enumerate(tables_data['tables']):
                        st.write(f"**Table {i+1}:**")
                        try:
                            # Convert to DataFrame for better visualization
                            if 'rows' in table and 'columns' in table:
                                df = pd.DataFrame(table['rows'], columns=table['columns'])
                                st.dataframe(df, use_container_width=True)
                        except:
                            st.write("Unable to display as DataFrame")
    
    with tab4:
        st.subheader("Export Options")
        
        # Combined JSON export
        combined_json = {
            'metadata': st.session_state.processed_data,
            'sheets': st.session_state.extracted_tables
        }
        
        # Pretty print JSON
        json_str = json.dumps(combined_json, indent=2, ensure_ascii=False)
        
        # Display JSON
        st.code(json_str, language='json')
        
        # Download button
        st.download_button(
            label="⬇️ Download Complete JSON",
            data=json_str,
            file_name=f"{st.session_state.processed_data['filename']}_extracted.json",
            mime="application/json",
            use_container_width=True
        )
        
        # Individual sheet downloads
        st.subheader("Download Individual Sheets")
        cols = st.columns(3)
        for i, sheet_name in enumerate(st.session_state.processed_data['sheets']):
            col = cols[i % 3]
            with col:
                sheet_json = json.dumps(
                    st.session_state.extracted_tables[sheet_name], 
                    indent=2, 
                    ensure_ascii=False
                )
                st.download_button(
                    label=f"📄 {sheet_name}.json",
                    data=sheet_json,
                    file_name=f"{sheet_name}.json",
                    mime="application/json"
                )

if __name__ == "__main__":
    main()
