"""
Configuration Module
Manages API keys and settings for the application
"""

import os
import json
from pathlib import Path
from typing import Dict, Optional

class Config:
    """Manage application configuration and credentials"""
    
    # Configuration file path
    CONFIG_FILE = Path.home() / ".rfi_processor_config.json"
    
    # Configuration cache
    _config = None
    
    @classmethod
    def set_azure_config(cls, api_key: str, endpoint: str, deployment_name: str):
        """
        Set Azure OpenAI configuration
        
        Args:
            api_key: Azure OpenAI API key
            endpoint: Azure OpenAI endpoint URL
            deployment_name: Deployment name for GPT-4
        """
        config = cls._load_config()
        
        config['azure_openai'] = {
            'api_key': api_key,
            'endpoint': endpoint,
            'deployment_name': deployment_name
        }
        
        cls._save_config(config)
        cls._config = config
    
    @classmethod
    def get_azure_config(cls) -> Optional[Dict[str, str]]:
        """
        Get Azure OpenAI configuration
        
        Returns:
            Dictionary with Azure OpenAI settings or None
        """
        config = cls._load_config()
        return config.get('azure_openai')
    
    @classmethod
    def is_configured(cls) -> bool:
        """
        Check if Azure OpenAI is configured
        
        Returns:
            Boolean indicating if configuration exists
        """
        config = cls.get_azure_config()
        return bool(config and config.get('api_key') and config.get('endpoint') and config.get('deployment_name'))
    
    @classmethod
    def _load_config(cls) -> Dict:
        """
        Load configuration from file or environment
        
        Returns:
            Configuration dictionary
        """
        if cls._config is not None:
            return cls._config
            
        # Try to load from file
        if cls.CONFIG_FILE.exists():
            try:
                with open(cls.CONFIG_FILE, 'r') as f:
                    cls._config = json.load(f)
                    return cls._config
            except Exception:
                pass
        
        # Try to load from environment variables
        config = {}
        
        # Check for Azure OpenAI environment variables
        if all([
            os.getenv('AZURE_OPENAI_API_KEY'),
            os.getenv('AZURE_OPENAI_ENDPOINT'),
            os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')
        ]):
            config['azure_openai'] = {
                'api_key': os.getenv('AZURE_OPENAI_API_KEY'),
                'endpoint': os.getenv('AZURE_OPENAI_ENDPOINT'),
                'deployment_name': os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')
            }
        
        cls._config = config
        return config
    
    @classmethod
    def _save_config(cls, config: Dict):
        """
        Save configuration to file
        
        Args:
            config: Configuration dictionary
        """
        try:
            # Ensure directory exists
            cls.CONFIG_FILE.parent.mkdir(exist_ok=True)
            
            # Save configuration
            with open(cls.CONFIG_FILE, 'w') as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            print(f"Warning: Could not save configuration: {str(e)}")
    
    @classmethod
    def clear_config(cls):
        """Clear all configuration"""
        cls._config = None
        if cls.CONFIG_FILE.exists():
            try:
                cls.CONFIG_FILE.unlink()
            except Exception:
                pass
