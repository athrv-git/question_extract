# RFI Excel Sheet Processor

A comprehensive Streamlit application for processing RFI (Request for Information) Excel sheets. This tool converts Excel sheets to markdown format and extracts structured tables using Azure OpenAI GPT-4.

## Features

- **Excel to Markdown Conversion**: Converts all sheets in an Excel file to markdown format
- **Intelligent Table Extraction**: Uses Azure OpenAI GPT-4 to identify and extract tables from unstructured data
- **Structured JSON Output**: Returns all tables in a structured JSON format with columns and values
- **Multiple Sheet Support**: Processes all sheets in the Excel file
- **Formatting Preservation**: Optionally preserves cell formatting information
- **Merged Cell Handling**: Smart handling of merged cells with multiple strategies
- **User-Friendly Interface**: Clean Streamlit interface with progress tracking

## Installation

1. Clone or download the repository
2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Configuration

### Azure OpenAI Setup

1. Obtain your Azure OpenAI credentials:
   - API Key
   - Endpoint URL (e.g., `https://your-resource.openai.azure.com/`)
   - Deployment Name (e.g., `gpt-4o`)

2. Configure in the application:
   - Run the Streamlit app
   - Enter credentials in the sidebar configuration section
   - Click "Save Configuration"

### Environment Variables (Optional)

You can also set credentials via environment variables:
```bash
export AZURE_OPENAI_API_KEY="your-api-key"
export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4o"
```

## Usage

1. Start the application:
```bash
streamlit run app.py
```

2. Configure Azure OpenAI settings in the sidebar

3. Upload your RFI Excel file

4. Select processing options:
   - Include empty cells
   - Preserve formatting
   - Merged cells handling strategy

5. Click "Process Excel File"

6. View results in different tabs:
   - **Summary**: Processing overview and statistics
   - **Markdown Files**: Generated markdown for each sheet
   - **Extracted Tables**: Structured JSON with all tables
   - **JSON Export**: Download complete results

## Project Structure

```
.
├── app.py                  # Main Streamlit application
├── excel_processor.py      # Excel file handling module
├── markdown_converter.py   # Excel to markdown conversion
├── azure_extractor.py      # Azure OpenAI table extraction
├── config.py              # Configuration management
├── requirements.txt       # Python dependencies
└── README.md             # This file
```

## Module Descriptions

### `app.py`
Main Streamlit application that provides the user interface and orchestrates the processing workflow.

### `excel_processor.py`
Handles Excel file reading and processing:
- Reads all sheets from Excel files
- Handles merged cells
- Preserves formatting information
- Supports multiple Excel formats (xlsx, xls, xlsm)

### `markdown_converter.py`
Converts Excel sheet data to markdown format:
- Detects table structures automatically
- Creates properly formatted markdown tables
- Handles non-tabular content
- Preserves sheet metadata

### `azure_extractor.py`
Extracts structured tables using Azure OpenAI:
- Sends markdown to GPT-4 for analysis
- Extracts all tables with columns and rows
- Returns structured JSON format
- Includes fallback extraction methods

### `config.py`
Manages application configuration:
- Stores Azure OpenAI credentials securely
- Supports environment variables
- Persistent configuration across sessions

## Output Format

The application returns structured JSON with the following format:

```json
{
  "metadata": {
    "filename": "example.xlsx",
    "sheets": ["Sheet1", "Sheet2"],
    "timestamp": "2024-01-01T12:00:00"
  },
  "sheets": {
    "Sheet1": {
      "sheet_name": "Sheet1",
      "tables": [
        {
          "table_id": 1,
          "title": "Table Title",
          "columns": ["Column1", "Column2", "Column3"],
          "rows": [
            ["Value1", "Value2", "Value3"],
            ["Value4", "Value5", "Value6"]
          ],
          "metadata": {
            "start_row": 1,
            "end_row": 10,
            "has_headers": true
          }
        }
      ]
    }
  }
}
```

## Processing Options

### Include Empty Cells
- When enabled: Preserves empty cells in the output
- When disabled: Skips empty cells for cleaner output

### Preserve Formatting
- When enabled: Captures cell formatting (bold, colors, etc.)
- When disabled: Extracts only cell values

### Merged Cells Handling
- **Expand to all cells**: Fills merged value in all cells of the range
- **Keep first cell only**: Preserves value only in the top-left cell
- **Mark as merged**: Tags cells that are part of merged ranges

## Error Handling

The application includes comprehensive error handling:
- Validates Azure OpenAI configuration before processing
- Falls back to regex-based extraction if API fails
- Provides detailed error messages
- Maintains partial results even if some sheets fail

## Performance Considerations

- Large Excel files are processed sheet by sheet
- Progress bar shows real-time processing status
- Markdown content is truncated if exceeding token limits
- Results are cached in session state for quick access

## Limitations

- Maximum file size depends on available memory
- Azure OpenAI token limits apply to markdown content
- Complex formatting may not be fully preserved
- Nested tables may require manual review

## Troubleshooting

### Azure OpenAI Connection Issues
- Verify API key is correct
- Check endpoint URL format
- Ensure deployment name matches your Azure setup

### Excel File Issues
- Ensure file is not corrupted
- Check file is not password protected
- Verify file extension matches content

### Memory Issues
- Process smaller files or individual sheets
- Reduce the number of sheets processed simultaneously
- Clear session state between large files

## Security Notes

- API keys are stored locally in user's home directory
- Credentials are never logged or displayed
- Temporary files are cleaned up after processing
- All processing happens locally except for Azure OpenAI calls

## Support

For issues or questions, please check:
1. Azure OpenAI documentation
2. Streamlit documentation
3. Error messages in the application

## License

This application is provided as-is for processing RFI Excel sheets.
