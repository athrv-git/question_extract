"""
Azure OpenAI Table Extractor Module
Extracts structured tables from markdown using Azure OpenAI GPT-4
"""

import json
import time
from typing import Dict, List, Any, Optional
from openai import AzureOpenAI
import re

class AzureTableExtractor:
    """Extract structured tables from markdown using Azure OpenAI"""
    
    def __init__(self):
        """Initialize Azure OpenAI client"""
        self.client = None
        self.deployment_name = None
        self.initialized = False
        
    def initialize(self, api_key: str, endpoint: str, deployment_name: str):
        """
        Initialize Azure OpenAI client with credentials
        
        Args:
            api_key: Azure OpenAI API key
            endpoint: Azure OpenAI endpoint URL
            deployment_name: Deployment name for GPT-4
        """
        try:
            self.client = AzureOpenAI(
                api_key=api_key,
                api_version="2024-02-01",
                azure_endpoint=endpoint
            )
            self.deployment_name = deployment_name
            self.initialized = True
        except Exception as e:
            raise Exception(f"Failed to initialize Azure OpenAI client: {str(e)}")
    
    def extract_tables(self, markdown_content: str, sheet_name: str) -> Dict[str, Any]:
        """
        Extract tables from markdown content using GPT-4
        
        Args:
            markdown_content: Markdown formatted content
            sheet_name: Name of the sheet being processed
            
        Returns:
            Structured JSON with extracted tables
        """
        if not self.initialized:
            # Try to get config from Config class
            from config import Config
            config = Config.get_azure_config()
            if config:
                try:
                    self.initialize(config['api_key'], config['endpoint'], config['deployment_name'])
                except Exception as e:
                    print(f"Warning: Could not initialize Azure OpenAI: {str(e)}")
                    print("Using fallback extraction method...")
                    return self._create_fallback_structure(markdown_content, sheet_name)
            else:
                print("Azure OpenAI not configured. Using fallback extraction method...")
                return self._create_fallback_structure(markdown_content, sheet_name)
        
        # Prepare the system prompt
        system_prompt = self._create_system_prompt()
        
        # Prepare the user message
        user_message = self._create_user_message(markdown_content, sheet_name)
        
        try:
            # Make API call with retry logic
            response = self._call_azure_openai_with_retry(system_prompt, user_message)
            
            # Parse the response
            extracted_data = self._parse_response(response)
            
            # Validate and clean the extracted data
            validated_data = self._validate_extracted_data(extracted_data)
            
            return validated_data
            
        except Exception as e:
            print(f"Error extracting tables: {str(e)}")
            # Return fallback structure
            return self._create_fallback_structure(markdown_content, sheet_name)
    
    def _create_system_prompt(self) -> str:
        """
        Create the system prompt for table extraction
        
        Returns:
            System prompt string
        """
        return """You are an expert data analyst specializing in extracting structured data from documents.
Your task is to analyze markdown content and extract ALL tables present in the document.

For each table found, you must:
1. Identify all column headers (even if implicit)
2. Extract all rows of data
3. Preserve the original data types (numbers as numbers, text as text)
4. Handle merged cells appropriately
5. Identify any metadata or context around the table

Return the results in the following JSON structure:
{
    "sheet_name": "Name of the sheet",
    "tables": [
        {
            "table_id": 1,
            "title": "Table title or description if available",
            "columns": ["Column1", "Column2", ...],
            "rows": [
                ["value1", "value2", ...],
                ["value1", "value2", ...]
            ],
            "metadata": {
                "start_row": 1,
                "end_row": 10,
                "has_headers": true,
                "notes": "Any relevant notes about the table"
            }
        }
    ],
    "non_tabular_content": [
        {
            "type": "heading|text|list",
            "content": "Content that is not part of a table"
        }
    ],
    "extraction_notes": "Any issues or observations during extraction"
}

Important guidelines:
- If a table has no explicit headers, infer them from context or use generic labels (Column1, Column2, etc.)
- Preserve empty cells as null or empty string
- If cells are merged, expand the value to all affected cells
- Numbers should remain as numbers, not strings
- Dates should be preserved in their original format
- If multiple tables are present, extract them all separately
- Include any text between tables in non_tabular_content"""
    
    def _create_user_message(self, markdown_content: str, sheet_name: str) -> str:
        """
        Create the user message for table extraction
        
        Args:
            markdown_content: Markdown formatted content
            sheet_name: Name of the sheet
            
        Returns:
            User message string
        """
        # Truncate very long content if necessary
        max_length = 30000  # Adjust based on token limits
        if len(markdown_content) > max_length:
            markdown_content = markdown_content[:max_length] + "\n...[Content truncated]..."
            
        return f"""Please extract all tables from the following markdown content from sheet '{sheet_name}':

---
{markdown_content}
---

Extract all tables and return them in the specified JSON format. Be thorough and include all data present in the document."""
    
    def _call_azure_openai_with_retry(self, system_prompt: str, user_message: str, max_retries: int = 3) -> str:
        """
        Call Azure OpenAI API with retry logic
        
        Args:
            system_prompt: System prompt
            user_message: User message
            max_retries: Maximum number of retries
            
        Returns:
            API response content
        """
        for attempt in range(max_retries):
            try:
                response = self.client.chat.completions.create(
                    model=self.deployment_name,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_message}
                    ],
                    temperature=0.1,  # Low temperature for consistent extraction
                    max_tokens=4000,
                    response_format={"type": "json_object"}  # Ensure JSON response
                )
                
                return response.choices[0].message.content
                
            except Exception as e:
                print(f"API call attempt {attempt + 1} failed: {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                else:
                    raise
    
    def _parse_response(self, response: str) -> Dict[str, Any]:
        """
        Parse the API response to extract JSON
        
        Args:
            response: API response string
            
        Returns:
            Parsed JSON data
        """
        try:
            # Try to parse as JSON directly
            return json.loads(response)
        except json.JSONDecodeError:
            # Try to extract JSON from the response
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                try:
                    return json.loads(json_match.group())
                except json.JSONDecodeError:
                    pass
            
            # If all else fails, return empty structure
            return {"tables": [], "extraction_notes": "Failed to parse response"}
    
    def _validate_extracted_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate and clean extracted data
        
        Args:
            data: Extracted data from API
            
        Returns:
            Validated and cleaned data
        """
        # Ensure required fields exist
        if 'tables' not in data:
            data['tables'] = []
            
        validated_tables = []
        
        for table in data.get('tables', []):
            # Validate table structure
            validated_table = {
                'table_id': table.get('table_id', len(validated_tables) + 1),
                'title': table.get('title', f"Table {len(validated_tables) + 1}"),
                'columns': table.get('columns', []),
                'rows': table.get('rows', []),
                'metadata': table.get('metadata', {})
            }
            
            # Ensure columns and rows are properly aligned
            if validated_table['columns'] and validated_table['rows']:
                num_cols = len(validated_table['columns'])
                
                # Adjust rows to match column count
                adjusted_rows = []
                for row in validated_table['rows']:
                    if len(row) < num_cols:
                        # Pad with empty values
                        row.extend([''] * (num_cols - len(row)))
                    elif len(row) > num_cols:
                        # Truncate extra values
                        row = row[:num_cols]
                    adjusted_rows.append(row)
                
                validated_table['rows'] = adjusted_rows
            
            # Clean up data types
            validated_table['rows'] = self._clean_data_types(validated_table['rows'])
            
            validated_tables.append(validated_table)
        
        data['tables'] = validated_tables
        
        return data
    
    def _clean_data_types(self, rows: List[List[Any]]) -> List[List[Any]]:
        """
        Clean and convert data types appropriately
        
        Args:
            rows: Table rows
            
        Returns:
            Rows with cleaned data types
        """
        cleaned_rows = []
        
        for row in rows:
            cleaned_row = []
            for value in row:
                # Try to convert to appropriate type
                if value is None or value == '':
                    cleaned_row.append('')
                elif isinstance(value, str):
                    # Try to convert to number if applicable
                    try:
                        if '.' in value:
                            cleaned_row.append(float(value))
                        else:
                            cleaned_row.append(int(value))
                    except ValueError:
                        # Keep as string
                        cleaned_row.append(value.strip())
                else:
                    cleaned_row.append(value)
            cleaned_rows.append(cleaned_row)
            
        return cleaned_rows
    
    def _create_fallback_structure(self, markdown_content: str, sheet_name: str) -> Dict[str, Any]:
        """
        Create a fallback structure when API extraction fails
        
        Args:
            markdown_content: Markdown content
            sheet_name: Sheet name
            
        Returns:
            Fallback structure
        """
        # Simple regex-based table extraction as fallback
        tables = []
        
        # Find markdown tables
        table_pattern = r'\|.*\|.*\n\|[\s\-:|]+\|.*\n(?:\|.*\|.*\n)+'
        matches = re.findall(table_pattern, markdown_content, re.MULTILINE)
        
        for i, match in enumerate(matches):
            lines = match.strip().split('\n')
            if len(lines) >= 3:  # At least header, separator, and one data row
                # Extract headers
                headers = [cell.strip() for cell in lines[0].split('|')[1:-1]]
                
                # Extract rows
                rows = []
                for line in lines[2:]:  # Skip header and separator
                    row = [cell.strip() for cell in line.split('|')[1:-1]]
                    rows.append(row)
                
                tables.append({
                    'table_id': i + 1,
                    'title': f"Table {i + 1}",
                    'columns': headers,
                    'rows': rows,
                    'metadata': {
                        'extracted_via': 'fallback_regex'
                    }
                })
        
        return {
            'sheet_name': sheet_name,
            'tables': tables,
            'extraction_notes': 'Extracted using fallback method due to API failure'
        }
