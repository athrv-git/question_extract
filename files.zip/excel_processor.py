"""
Excel Processor Module
Handles reading and processing Excel files with various formatting options
"""

import pandas as pd
import openpyxl
from openpyxl.utils import get_column_letter
from typing import Dict, List, Any, Optional
import numpy as np

class ExcelProcessor:
    """Process Excel files and extract data from all sheets"""
    
    def __init__(self, include_empty_cells=False, preserve_formatting=True, merge_cells_handling="Expand to all cells"):
        """
        Initialize Excel processor with configuration options
        
        Args:
            include_empty_cells: Whether to include empty cells in output
            preserve_formatting: Whether to preserve cell formatting information
            merge_cells_handling: How to handle merged cells
        """
        self.include_empty_cells = include_empty_cells
        self.preserve_formatting = preserve_formatting
        self.merge_cells_handling = merge_cells_handling
        
    def read_excel(self, file_path: str) -> Dict[str, Any]:
        """
        Read Excel file and extract data from all sheets
        
        Args:
            file_path: Path to the Excel file
            
        Returns:
            Dictionary with sheet names as keys and sheet data as values
        """
        sheets_data = {}
        
        try:
            # Load workbook using openpyxl for better formatting support
            workbook = openpyxl.load_workbook(file_path, data_only=True)
            
            for sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]
                sheet_data = self._process_sheet(sheet, sheet_name)
                sheets_data[sheet_name] = sheet_data
                
            workbook.close()
            
        except Exception as e:
            # Fallback to pandas if openpyxl fails
            print(f"Openpyxl failed, using pandas: {str(e)}")
            xls = pd.ExcelFile(file_path)
            
            for sheet_name in xls.sheet_names:
                df = pd.read_excel(xls, sheet_name=sheet_name, header=None)
                sheet_data = self._process_dataframe(df, sheet_name)
                sheets_data[sheet_name] = sheet_data
                
        return sheets_data
    
    def _process_sheet(self, sheet, sheet_name: str) -> Dict[str, Any]:
        """
        Process a single sheet from openpyxl workbook
        
        Args:
            sheet: Openpyxl worksheet object
            sheet_name: Name of the sheet
            
        Returns:
            Dictionary containing sheet data and metadata
        """
        sheet_data = {
            'name': sheet_name,
            'data': [],
            'merged_cells': [],
            'formatting': [],
            'dimensions': {
                'rows': sheet.max_row,
                'columns': sheet.max_column
            }
        }
        
        # Handle merged cells
        merged_ranges = []
        for merged_range in sheet.merged_cells.ranges:
            merged_info = {
                'range': str(merged_range),
                'min_row': merged_range.min_row,
                'max_row': merged_range.max_row,
                'min_col': merged_range.min_col,
                'max_col': merged_range.max_col
            }
            merged_ranges.append(merged_info)
        sheet_data['merged_cells'] = merged_ranges
        
        # Process all cells
        for row_idx in range(1, sheet.max_row + 1):
            row_data = []
            for col_idx in range(1, sheet.max_column + 1):
                cell = sheet.cell(row=row_idx, column=col_idx)
                cell_data = self._extract_cell_data(cell)
                
                # Skip empty cells if configured
                if not self.include_empty_cells and cell_data['value'] is None:
                    cell_data['value'] = ''
                    
                row_data.append(cell_data)
            sheet_data['data'].append(row_data)
            
        # Handle merged cells based on configuration
        if self.merge_cells_handling == "Expand to all cells":
            self._expand_merged_cells(sheet_data)
        elif self.merge_cells_handling == "Mark as merged":
            self._mark_merged_cells(sheet_data)
            
        return sheet_data
    
    def _extract_cell_data(self, cell) -> Dict[str, Any]:
        """
        Extract data and formatting from a cell
        
        Args:
            cell: Openpyxl cell object
            
        Returns:
            Dictionary containing cell data and metadata
        """
        cell_data = {
            'value': cell.value,
            'coordinate': cell.coordinate,
            'row': cell.row,
            'column': cell.column,
            'column_letter': get_column_letter(cell.column)
        }
        
        if self.preserve_formatting and cell.value is not None:
            # Extract formatting information
            cell_data['formatting'] = {
                'bold': cell.font.bold if cell.font else False,
                'italic': cell.font.italic if cell.font else False,
                'font_size': cell.font.size if cell.font else None,
                'font_color': cell.font.color.rgb if cell.font and cell.font.color else None,
                'bg_color': cell.fill.fgColor.rgb if cell.fill and cell.fill.fgColor else None,
                'number_format': cell.number_format,
                'alignment': {
                    'horizontal': cell.alignment.horizontal if cell.alignment else None,
                    'vertical': cell.alignment.vertical if cell.alignment else None
                }
            }
            
        return cell_data
    
    def _expand_merged_cells(self, sheet_data: Dict[str, Any]):
        """
        Expand merged cells to fill all cells in the range
        
        Args:
            sheet_data: Dictionary containing sheet data
        """
        for merged_range in sheet_data['merged_cells']:
            # Get the value from the top-left cell
            min_row = merged_range['min_row'] - 1
            min_col = merged_range['min_col'] - 1
            
            if min_row < len(sheet_data['data']) and min_col < len(sheet_data['data'][min_row]):
                value = sheet_data['data'][min_row][min_col]['value']
                
                # Expand to all cells in the range
                for row in range(merged_range['min_row'] - 1, merged_range['max_row']):
                    for col in range(merged_range['min_col'] - 1, merged_range['max_col']):
                        if row < len(sheet_data['data']) and col < len(sheet_data['data'][row]):
                            sheet_data['data'][row][col]['value'] = value
                            sheet_data['data'][row][col]['is_merged'] = True
    
    def _mark_merged_cells(self, sheet_data: Dict[str, Any]):
        """
        Mark cells that are part of merged ranges
        
        Args:
            sheet_data: Dictionary containing sheet data
        """
        for merged_range in sheet_data['merged_cells']:
            for row in range(merged_range['min_row'] - 1, merged_range['max_row']):
                for col in range(merged_range['min_col'] - 1, merged_range['max_col']):
                    if row < len(sheet_data['data']) and col < len(sheet_data['data'][row]):
                        sheet_data['data'][row][col]['is_merged'] = True
                        sheet_data['data'][row][col]['merged_range'] = merged_range['range']
    
    def _process_dataframe(self, df: pd.DataFrame, sheet_name: str) -> Dict[str, Any]:
        """
        Process a pandas DataFrame (fallback method)
        
        Args:
            df: Pandas DataFrame
            sheet_name: Name of the sheet
            
        Returns:
            Dictionary containing sheet data
        """
        sheet_data = {
            'name': sheet_name,
            'data': [],
            'dimensions': {
                'rows': len(df),
                'columns': len(df.columns)
            }
        }
        
        # Convert DataFrame to list of lists with metadata
        for row_idx, row in df.iterrows():
            row_data = []
            for col_idx, value in enumerate(row):
                # Handle NaN values
                if pd.isna(value):
                    value = '' if not self.include_empty_cells else None
                    
                cell_data = {
                    'value': value,
                    'row': row_idx + 1,
                    'column': col_idx + 1,
                    'column_letter': get_column_letter(col_idx + 1)
                }
                row_data.append(cell_data)
            sheet_data['data'].append(row_data)
            
        return sheet_data
    
    def get_sheet_summary(self, sheet_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a summary of sheet characteristics
        
        Args:
            sheet_data: Dictionary containing sheet data
            
        Returns:
            Summary statistics for the sheet
        """
        summary = {
            'name': sheet_data['name'],
            'dimensions': sheet_data['dimensions'],
            'merged_cells_count': len(sheet_data.get('merged_cells', [])),
            'non_empty_cells': 0,
            'empty_cells': 0,
            'total_cells': sheet_data['dimensions']['rows'] * sheet_data['dimensions']['columns']
        }
        
        # Count non-empty cells
        for row in sheet_data['data']:
            for cell in row:
                if cell['value'] not in [None, '', 'nan', 'NaN']:
                    summary['non_empty_cells'] += 1
                else:
                    summary['empty_cells'] += 1
                    
        summary['fill_rate'] = (summary['non_empty_cells'] / summary['total_cells'] * 100) if summary['total_cells'] > 0 else 0
        
        return summary
