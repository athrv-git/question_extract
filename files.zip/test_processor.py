"""
Test Script for RFI Excel Processor
Demonstrates the core functionality without Streamlit UI
"""

import pandas as pd
import json
from pathlib import Path
import tempfile

# Import modules
from excel_processor import ExcelProcessor
from markdown_converter import MarkdownConverter
from azure_extractor import AzureTableExtractor
from config import Config

def create_sample_excel():
    """Create a sample Excel file for testing"""
    # Create sample data
    sample_data = {
        'Sheet1': pd.DataFrame({
            'Project ID': ['PRJ-001', 'PRJ-002', 'PRJ-003'],
            'Description': ['Foundation work', 'Steel structure', 'Roofing'],
            'Status': ['Complete', 'In Progress', 'Pending'],
            'Cost': [50000, 120000, 35000],
            'Deadline': ['2024-01-15', '2024-02-28', '2024-03-15']
        }),
        'Sheet2': pd.DataFrame({
            'Item': ['Concrete', 'Steel Beams', 'Bolts', 'Paint'],
            'Quantity': [100, 50, 500, 20],
            'Unit': ['m³', 'tons', 'pcs', 'gallons'],
            'Unit Price': [150, 2000, 5, 50],
            'Total': [15000, 100000, 2500, 1000]
        })
    }
    
    # Save to Excel file
    temp_file = tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False)
    with pd.ExcelWriter(temp_file.name, engine='openpyxl') as writer:
        for sheet_name, df in sample_data.items():
            df.to_excel(writer, sheet_name=sheet_name, index=False)
    
    return temp_file.name

def test_without_azure():
    """Test the processing without Azure OpenAI (using fallback)"""
    print("=" * 60)
    print("RFI Excel Processor - Test Script")
    print("=" * 60)
    
    # Create sample Excel file
    print("\n1. Creating sample Excel file...")
    excel_file = create_sample_excel()
    print(f"   Sample file created: {excel_file}")
    
    # Initialize processors
    print("\n2. Initializing processors...")
    excel_processor = ExcelProcessor(
        include_empty_cells=False,
        preserve_formatting=True,
        merge_cells_handling="Expand to all cells"
    )
    markdown_converter = MarkdownConverter()
    azure_extractor = AzureTableExtractor()
    
    # Process Excel file
    print("\n3. Reading Excel file...")
    sheets_data = excel_processor.read_excel(excel_file)
    print(f"   Found {len(sheets_data)} sheets: {list(sheets_data.keys())}")
    
    # Convert to Markdown
    print("\n4. Converting to Markdown...")
    markdown_files = {}
    for sheet_name, sheet_data in sheets_data.items():
        # Get summary
        summary = excel_processor.get_sheet_summary(sheet_data)
        print(f"\n   Sheet: {sheet_name}")
        print(f"   - Dimensions: {summary['dimensions']['rows']} rows × {summary['dimensions']['columns']} columns")
        print(f"   - Non-empty cells: {summary['non_empty_cells']}")
        print(f"   - Fill rate: {summary['fill_rate']:.1f}%")
        
        # Convert to markdown
        markdown_content = markdown_converter.convert_to_markdown(sheet_data, sheet_name)
        markdown_files[sheet_name] = markdown_content
        
        # Save markdown file
        md_file = f"{sheet_name}.md"
        with open(md_file, 'w') as f:
            f.write(markdown_content)
        print(f"   - Markdown saved to: {md_file}")
    
    # Display markdown content
    print("\n5. Markdown Content Preview:")
    print("-" * 40)
    for sheet_name, content in markdown_files.items():
        print(f"\n### {sheet_name}.md ###")
        lines = content.split('\n')[:20]  # Show first 20 lines
        for line in lines:
            print(line)
        if len(content.split('\n')) > 20:
            print("... [truncated] ...")
    
    # Extract tables (using fallback method)
    print("\n6. Extracting structured tables...")
    print("   Note: Using fallback extraction (no Azure OpenAI configured)")
    extracted_tables = {}
    for sheet_name, markdown_content in markdown_files.items():
        tables_json = azure_extractor.extract_tables(markdown_content, sheet_name)
        extracted_tables[sheet_name] = tables_json
        print(f"   - {sheet_name}: {len(tables_json.get('tables', []))} tables extracted")
    
    # Save results to JSON
    print("\n7. Saving results to JSON...")
    output_json = {
        'metadata': {
            'source_file': excel_file,
            'sheets': list(sheets_data.keys())
        },
        'extracted_tables': extracted_tables
    }
    
    output_file = 'extracted_tables.json'
    with open(output_file, 'w') as f:
        json.dump(output_json, f, indent=2)
    print(f"   Results saved to: {output_file}")
    
    # Display JSON preview
    print("\n8. JSON Output Preview:")
    print("-" * 40)
    print(json.dumps(output_json, indent=2)[:1000])
    if len(json.dumps(output_json)) > 1000:
        print("... [truncated] ...")
    
    print("\n" + "=" * 60)
    print("Test completed successfully!")
    print("=" * 60)
    
    # Clean up
    Path(excel_file).unlink()
    
    return extracted_tables

def test_with_azure(api_key: str, endpoint: str, deployment_name: str):
    """Test with Azure OpenAI configured"""
    # Configure Azure OpenAI
    Config.set_azure_config(api_key, endpoint, deployment_name)
    
    # Run the same test
    return test_without_azure()

if __name__ == "__main__":
    print("\nRunning test without Azure OpenAI (using fallback extraction)...")
    print("To test with Azure OpenAI, configure your credentials and call test_with_azure()")
    
    # Run test
    results = test_without_azure()
    
    print("\n" + "=" * 60)
    print("Instructions for running with Streamlit:")
    print("=" * 60)
    print("1. Install requirements: pip install -r requirements.txt")
    print("2. Run the app: streamlit run app.py")
    print("3. Configure Azure OpenAI in the sidebar")
    print("4. Upload your RFI Excel file")
    print("5. Process and download results")
    print("=" * 60)
