"""
Markdown Converter Module
Converts Excel sheet data to markdown format
"""

from typing import Dict, List, Any, Optional
import re

class MarkdownConverter:
    """Convert Excel sheet data to markdown format"""
    
    def __init__(self):
        """Initialize markdown converter"""
        self.table_detection_threshold = 0.7  # Threshold for detecting table structures
        
    def convert_to_markdown(self, sheet_data: Dict[str, Any], sheet_name: str) -> str:
        """
        Convert sheet data to markdown format
        
        Args:
            sheet_data: Dictionary containing sheet data
            sheet_name: Name of the sheet
            
        Returns:
            Markdown formatted string
        """
        markdown_lines = []
        
        # Add header with sheet name
        markdown_lines.append(f"# {sheet_name}")
        markdown_lines.append("")
        
        # Add metadata
        markdown_lines.append("## Sheet Information")
        markdown_lines.append(f"- **Rows**: {sheet_data['dimensions']['rows']}")
        markdown_lines.append(f"- **Columns**: {sheet_data['dimensions']['columns']}")
        if sheet_data.get('merged_cells'):
            markdown_lines.append(f"- **Merged Cells**: {len(sheet_data['merged_cells'])}")
        markdown_lines.append("")
        
        # Process the data
        markdown_lines.append("## Data Content")
        markdown_lines.append("")
        
        # Detect and convert tables
        tables = self._detect_tables(sheet_data['data'])
        
        if tables:
            for i, table in enumerate(tables):
                if table['type'] == 'table':
                    markdown_lines.append(f"### Table {i + 1}")
                    markdown_lines.append("")
                    markdown_lines.extend(self._create_markdown_table(table['data']))
                    markdown_lines.append("")
                else:
                    # Handle non-tabular data
                    markdown_lines.extend(self._create_markdown_list(table['data']))
                    markdown_lines.append("")
        else:
            # Fallback: Convert entire sheet as single table
            markdown_lines.extend(self._create_full_sheet_markdown(sheet_data['data']))
            
        return "\n".join(markdown_lines)
    
    def _detect_tables(self, data: List[List[Dict]]) -> List[Dict]:
        """
        Detect table structures in the data
        
        Args:
            data: Sheet data as list of rows
            
        Returns:
            List of detected tables and data sections
        """
        tables = []
        current_table = []
        is_in_table = False
        empty_row_count = 0
        
        for row_idx, row in enumerate(data):
            # Check if row is empty
            row_values = [cell['value'] for cell in row if cell['value'] not in [None, '', 'nan']]
            
            if not row_values:
                empty_row_count += 1
                # If we have accumulated a table and hit empty rows, save it
                if is_in_table and empty_row_count > 1:
                    if len(current_table) > 1:
                        tables.append({
                            'type': 'table',
                            'start_row': row_idx - len(current_table) - empty_row_count + 1,
                            'end_row': row_idx - empty_row_count,
                            'data': current_table
                        })
                    current_table = []
                    is_in_table = False
            else:
                empty_row_count = 0
                
                # Check if this looks like a table row
                if self._is_table_row(row):
                    is_in_table = True
                    current_table.append(row)
                else:
                    # Save current table if exists
                    if is_in_table and len(current_table) > 1:
                        tables.append({
                            'type': 'table',
                            'start_row': row_idx - len(current_table),
                            'end_row': row_idx - 1,
                            'data': current_table
                        })
                        current_table = []
                        is_in_table = False
                    
                    # Add as non-table data
                    tables.append({
                        'type': 'text',
                        'row': row_idx,
                        'data': [row]
                    })
        
        # Add remaining table if exists
        if current_table and len(current_table) > 1:
            tables.append({
                'type': 'table',
                'start_row': len(data) - len(current_table),
                'end_row': len(data) - 1,
                'data': current_table
            })
            
        return tables
    
    def _is_table_row(self, row: List[Dict]) -> bool:
        """
        Determine if a row looks like part of a table
        
        Args:
            row: Row data
            
        Returns:
            Boolean indicating if row appears to be part of a table
        """
        # Count non-empty cells
        non_empty = sum(1 for cell in row if cell['value'] not in [None, '', 'nan'])
        total_cells = len(row)
        
        # A row is considered part of a table if it has multiple filled cells
        if total_cells > 0:
            fill_ratio = non_empty / total_cells
            return non_empty >= 2 and fill_ratio >= 0.3
        return False
    
    def _create_markdown_table(self, data: List[List[Dict]]) -> List[str]:
        """
        Create a markdown table from data
        
        Args:
            data: Table data
            
        Returns:
            List of markdown lines forming a table
        """
        if not data:
            return []
            
        markdown_lines = []
        
        # Determine the maximum number of columns
        max_cols = max(len(row) for row in data)
        
        # Process each row
        for row_idx, row in enumerate(data):
            # Create row values
            row_values = []
            for col_idx in range(max_cols):
                if col_idx < len(row):
                    value = row[col_idx]['value']
                    # Clean and format the value
                    if value is None or value == '' or str(value).lower() == 'nan':
                        value = ' '
                    else:
                        value = str(value).strip()
                        # Escape pipe characters
                        value = value.replace('|', '\\|')
                        # Limit cell width for readability
                        if len(value) > 50:
                            value = value[:47] + '...'
                    row_values.append(value)
                else:
                    row_values.append(' ')
            
            # Create markdown row
            markdown_row = '| ' + ' | '.join(row_values) + ' |'
            markdown_lines.append(markdown_row)
            
            # Add separator after first row (header)
            if row_idx == 0:
                separator = '|' + '|'.join([' --- ' for _ in range(max_cols)]) + '|'
                markdown_lines.append(separator)
                
        return markdown_lines
    
    def _create_markdown_list(self, data: List[List[Dict]]) -> List[str]:
        """
        Create a markdown list from non-tabular data
        
        Args:
            data: Non-tabular data
            
        Returns:
            List of markdown lines
        """
        markdown_lines = []
        
        for row in data:
            # Concatenate non-empty values
            values = []
            for cell in row:
                if cell['value'] not in [None, '', 'nan']:
                    values.append(str(cell['value']).strip())
            
            if values:
                # Join values and create a list item or paragraph
                content = ' | '.join(values)
                if len(values) == 1:
                    # Single value - make it a heading or paragraph
                    if self._looks_like_heading(values[0]):
                        markdown_lines.append(f"### {values[0]}")
                    else:
                        markdown_lines.append(values[0])
                else:
                    # Multiple values - make it a list item
                    markdown_lines.append(f"- {content}")
                    
        return markdown_lines
    
    def _looks_like_heading(self, text: str) -> bool:
        """
        Determine if text looks like a heading
        
        Args:
            text: Text to check
            
        Returns:
            Boolean indicating if text appears to be a heading
        """
        # Simple heuristic: short, title-case, or all caps
        if len(text) < 50:
            if text.isupper() or text.istitle():
                return True
        return False
    
    def _create_full_sheet_markdown(self, data: List[List[Dict]]) -> List[str]:
        """
        Convert entire sheet to markdown table (fallback method)
        
        Args:
            data: Sheet data
            
        Returns:
            List of markdown lines
        """
        markdown_lines = []
        
        if not data:
            return ["*No data in sheet*"]
        
        # Find the maximum number of columns
        max_cols = max(len(row) for row in data) if data else 0
        
        # Create header row with column letters
        header = '| ' + ' | '.join([f"Col {chr(65 + i)}" for i in range(max_cols)]) + ' |'
        separator = '|' + '|'.join([' --- ' for _ in range(max_cols)]) + '|'
        
        markdown_lines.append(header)
        markdown_lines.append(separator)
        
        # Add data rows
        for row in data:
            row_values = []
            for col_idx in range(max_cols):
                if col_idx < len(row):
                    value = row[col_idx]['value']
                    if value is None or value == '' or str(value).lower() == 'nan':
                        value = ' '
                    else:
                        value = str(value).strip()
                        value = value.replace('|', '\\|')
                        if len(value) > 50:
                            value = value[:47] + '...'
                    row_values.append(value)
                else:
                    row_values.append(' ')
            
            markdown_row = '| ' + ' | '.join(row_values) + ' |'
            markdown_lines.append(markdown_row)
            
        return markdown_lines
    
    def add_formatting_info(self, markdown: str, sheet_data: Dict[str, Any]) -> str:
        """
        Add formatting information to markdown (if preserved)
        
        Args:
            markdown: Base markdown content
            sheet_data: Sheet data with formatting info
            
        Returns:
            Enhanced markdown with formatting notes
        """
        if not any(cell.get('formatting') for row in sheet_data['data'] for cell in row):
            return markdown
            
        formatting_notes = ["\n## Formatting Notes\n"]
        
        # Collect cells with special formatting
        bold_cells = []
        colored_cells = []
        merged_info = sheet_data.get('merged_cells', [])
        
        for row in sheet_data['data']:
            for cell in row:
                if cell.get('formatting'):
                    fmt = cell['formatting']
                    coord = cell.get('coordinate', f"{cell['column_letter']}{cell['row']}")
                    
                    if fmt.get('bold'):
                        bold_cells.append(coord)
                    if fmt.get('bg_color') and fmt['bg_color'] != 'FFFFFF':
                        colored_cells.append(f"{coord} (bg: #{fmt['bg_color']})")
        
        if bold_cells:
            formatting_notes.append(f"- **Bold cells**: {', '.join(bold_cells[:10])}")
            if len(bold_cells) > 10:
                formatting_notes.append(f"  (and {len(bold_cells) - 10} more)")
                
        if colored_cells:
            formatting_notes.append(f"- **Colored cells**: {', '.join(colored_cells[:5])}")
            if len(colored_cells) > 5:
                formatting_notes.append(f"  (and {len(colored_cells) - 5} more)")
                
        if merged_info:
            formatting_notes.append(f"- **Merged cell ranges**: {len(merged_info)} ranges")
            for merge in merged_info[:3]:
                formatting_notes.append(f"  - {merge['range']}")
            if len(merged_info) > 3:
                formatting_notes.append(f"  (and {len(merged_info) - 3} more)")
        
        return markdown + '\n'.join(formatting_notes)
